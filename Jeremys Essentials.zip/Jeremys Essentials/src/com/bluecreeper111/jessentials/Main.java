package com.bluecreeper111.jessentials;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

import com.bluecreeper111.jessentials.api.teleportDelay;
import com.bluecreeper111.jessentials.api.teleportSafety;
import com.bluecreeper111.jessentials.commands.Back;
import com.bluecreeper111.jessentials.commands.Broadcast;
import com.bluecreeper111.jessentials.commands.ChatClear;
import com.bluecreeper111.jessentials.commands.Clear;
import com.bluecreeper111.jessentials.commands.DelHome;
import com.bluecreeper111.jessentials.commands.Enchant;
import com.bluecreeper111.jessentials.commands.Enderchest;
import com.bluecreeper111.jessentials.commands.Exp;
import com.bluecreeper111.jessentials.commands.Feed;
import com.bluecreeper111.jessentials.commands.Fly;
import com.bluecreeper111.jessentials.commands.Gamemode;
import com.bluecreeper111.jessentials.commands.God;
import com.bluecreeper111.jessentials.commands.Hat;
import com.bluecreeper111.jessentials.commands.Heal;
import com.bluecreeper111.jessentials.commands.Home;
import com.bluecreeper111.jessentials.commands.JEssentials;
import com.bluecreeper111.jessentials.commands.Motd;
import com.bluecreeper111.jessentials.commands.SetHome;
import com.bluecreeper111.jessentials.commands.Workbench;
import com.bluecreeper111.jessentials.event.playerDeath;
import com.bluecreeper111.jessentials.event.playerGamemode;
import com.bluecreeper111.jessentials.event.playerGive;
import com.bluecreeper111.jessentials.event.playerJoinLeave;


public class Main extends JavaPlugin {
	
	public static String noPermissionMessage;
	public static String notPlayerMessage;
	public static String playerNotFound;
	public static String incorrectSyntaxMessage;
	public static Long tpDelay;
	public static boolean tpDelayEnable;
	public static Long tpSafetyLength;
	public static String teleportMessage;
	public static BukkitScheduler scheduler;
	
	
	public void onEnable() {
		Logger logger = Bukkit.getLogger();
		PluginDescriptionFile pdfFile = this.getDescription();
		
		logger.info("JEssentials -INFO- has been enabled successfuly.");
		logger.info("JEssentials -VERSION- Running version V." + pdfFile.getVersion());
		registerCommands();
		registerEvents();
		saveDefaultConfig();
		registerPermissions();
		registerApiStrings();
		loadMetrics();
	}
	
	public void onDisable() {
		Logger logger = Bukkit.getLogger();
		
		logger.info("JEssentials -INFO- has been disabled with no errors.");
		
	}
	
	public void registerCommands() {
		getCommand("heal").setExecutor(new Heal(this));
		getCommand("feed").setExecutor(new Feed(this));
		getCommand("clear").setExecutor(new Clear(this));
		getCommand("fly").setExecutor(new Fly(this));
		getCommand("gmc").setExecutor(new Gamemode(this));
		getCommand("gms").setExecutor(new Gamemode(this));
		getCommand("gma").setExecutor(new Gamemode(this));
		getCommand("gmsp").setExecutor(new Gamemode(this));
		getCommand("workbench").setExecutor(new Workbench(this));
		getCommand("god").setExecutor(new God(this));
		getCommand("enchant").setExecutor(new Enchant(this));
		getCommand("jessentials").setExecutor(new JEssentials(this));
		getCommand("broadcast").setExecutor(new Broadcast(this));
		getCommand("chatclear").setExecutor(new ChatClear(this));
		getCommand("enderchest").setExecutor(new Enderchest(this));
		getCommand("motd").setExecutor(new Motd(this));
		getCommand("exp").setExecutor(new Exp(this));
		getCommand("sethome").setExecutor(new SetHome(this));
		getCommand("delhome").setExecutor(new DelHome(this));
		getCommand("home").setExecutor(new Home(this));
		getCommand("hat").setExecutor(new Hat(this));
		getCommand("back").setExecutor(new Back(this));
	}
	
	public void registerEvents() {
		PluginManager pm = Bukkit.getPluginManager();
		pm.registerEvents(new playerGamemode(this), this);
		pm.registerEvents(new God(this), this);
		pm.registerEvents(new playerGive(this), this);
		pm.registerEvents(new playerJoinLeave(this), this);
		pm.registerEvents(new teleportSafety(this), this);
		pm.registerEvents(new teleportDelay(), this);
		pm.registerEvents(new playerDeath(), this);
		
	}
	
	public void registerPermissions() {
		PluginManager pm = Bukkit.getPluginManager();
		pm.addPermission(new Permission("jessentials.heal"));
		pm.addPermission(new Permission("jessentials.heal.others"));
		pm.addPermission(new Permission("jessentials.feed"));
		pm.addPermission(new Permission("jessentials.feed.others"));
		pm.addPermission(new Permission("jessentials.clear"));
		pm.addPermission(new Permission("jessentials.clear.others"));
		pm.addPermission(new Permission("jessentials.fly"));
		pm.addPermission(new Permission("jessentials.fly.others"));
		pm.addPermission(new Permission("jessentials.gmc"));
		pm.addPermission(new Permission("jessentials.gmc.others"));
		pm.addPermission(new Permission("jessentials.gms"));
		pm.addPermission(new Permission("jessentials.gms.others"));
		pm.addPermission(new Permission("jessentials.gmsp"));
		pm.addPermission(new Permission("jessentials.gmsp.others"));
		pm.addPermission(new Permission("jessentials.gma"));
		pm.addPermission(new Permission("jessentials.gma.others"));
		pm.addPermission(new Permission("jessentials.gamemode"));
		pm.addPermission(new Permission("jessentials.workbench"));
		pm.addPermission(new Permission("jessentials.god"));
		pm.addPermission(new Permission("jessentials.god.others"));
		pm.addPermission(new Permission("jessentials.enchant"));
		pm.addPermission(new Permission("jessentials.enchant.*"));
		pm.addPermission(new Permission("jessentials.enchant.protection"));
		pm.addPermission(new Permission("jessentials.enchant.fire_protection"));
		pm.addPermission(new Permission("jessentials.enchant.fall_protection"));
		pm.addPermission(new Permission("jessentials.enchant.explosions_protection"));
		pm.addPermission(new Permission("jessentials.enchant.projectile_protection"));
		pm.addPermission(new Permission("jessentials.enchant.respiration"));
		pm.addPermission(new Permission("jessentials.enchant.thorns"));
		pm.addPermission(new Permission("jessentials.enchant.aqua_affinity"));
		pm.addPermission(new Permission("jessentials.enchant.depth_strider"));
		pm.addPermission(new Permission("jessentials.enchant.binding_curse"));
		pm.addPermission(new Permission("jessentials.enchant.frost_walker"));
		pm.addPermission(new Permission("jessentials.enchant.smite"));
		pm.addPermission(new Permission("jessentials.enchant.sharpness"));
		pm.addPermission(new Permission("jessentials.enchant.bane_of_arthropods"));
		pm.addPermission(new Permission("jessentials.enchant.knockback"));
		pm.addPermission(new Permission("jessentials.enchant.fire_aspect"));
		pm.addPermission(new Permission("jessentials.enchant.looting"));
		pm.addPermission(new Permission("jessentials.enchant.sweeping_edge"));
		pm.addPermission(new Permission("jessentials.enchant.unbreaking"));
		pm.addPermission(new Permission("jessentials.enchant.silk_touch"));
		pm.addPermission(new Permission("jessentials.enchant.efficiency"));
		pm.addPermission(new Permission("jessentials.enchant.power"));
		pm.addPermission(new Permission("jessentials.enchant.fortune"));
		pm.addPermission(new Permission("jessentials.enchant.flame"));
		pm.addPermission(new Permission("jessentials.enchant.punch"));
		pm.addPermission(new Permission("jessentials.enchant.infinity"));
		pm.addPermission(new Permission("jessentials.enchant.luck_of_the_sea"));
		pm.addPermission(new Permission("jessentials.enchant.mending"));
		pm.addPermission(new Permission("jessentials.enchant.lure"));
		pm.addPermission(new Permission("jessentials.enchant.vanishing_curse"));
		pm.addPermission(new Permission("jessentials.give"));
		pm.addPermission(new Permission("jessentials.info"));
		pm.addPermission(new Permission("jessentials.broadcast"));
		pm.addPermission(new Permission("jessentials.chatclear"));
		pm.addPermission(new Permission("jessentials.chatclear.others"));
		pm.addPermission(new Permission("jessentials.reload"));
		pm.addPermission(new Permission("jessentials.enderchest"));
		pm.addPermission(new Permission("jessentials.enderchest.others"));
		pm.addPermission(new Permission("jessentials.motd"));
		pm.addPermission(new Permission("jessentials.motd.set"));
		pm.addPermission(new Permission("jessentials.motd.enable"));
		pm.addPermission(new Permission("jessentials.exp"));
		pm.addPermission(new Permission("jessentials.exp.others"));
		pm.addPermission(new Permission("jessentials.sethome"));
		pm.addPermission(new Permission("jessentials.sethome.multiple"));
		pm.addPermission(new Permission("jessentials.delhome"));
		pm.addPermission(new Permission("jessentials.home"));
		pm.addPermission(new Permission("jessentials.hat"));
		pm.addPermission(new Permission("jessentials.back"));
		pm.addPermission(new Permission("jessentials.back.others"));
		pm.addPermission(new Permission("jessentials.tpdelay.bypass"));
		
		
		
		
	}
	
	public void saveDefaultConfig() {
        if (!new File(getDataFolder(), "config.yml").exists()) {
            saveResource("config.yml", false);
        }
    }
	
	public void registerApiStrings() {
		noPermissionMessage = getConfig().getString("noPermissionMessage");
		notPlayerMessage = getConfig().getString("noPlayerMessage");
		playerNotFound = getConfig().getString("pNotFoundMessage");
		incorrectSyntaxMessage = getConfig().getString("incorrectSyntaxMessage");
		tpDelay = getConfig().getInt("tpDelay") * 20L;
		tpDelayEnable = getConfig().getBoolean("enable-tpDelay");
		scheduler = getServer().getScheduler();
		tpSafetyLength = getConfig().getInt("tpSafetyLength") * 20L;
		teleportMessage = ChatColor.translateAlternateColorCodes('&', getConfig().getString("tpMessage"));
	}
	public void loadHomes() {
		File file = new File("plugins/JEssentials", "homes.yml");
		FileConfiguration fileCfg = YamlConfiguration.loadConfiguration(file);
		if (!file.exists()) {
			try {
				fileCfg.save(file);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public void loadMetrics() {
		Metrics metrics = new Metrics(this);
	    metrics.addCustomChart(new Metrics.SimplePie("used_language", new Callable<String>() {
	        @Override
	        public String call() throws Exception {
	            return getConfig().getString("language", "en");
	        }
	    }));
	}

}
