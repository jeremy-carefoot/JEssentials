package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.bluecreeper111.jessentials.Main;
import com.bluecreeper111.jessentials.api.api;
import com.bluecreeper111.jessentials.event.playerDeath;

public class Back implements CommandExecutor {

	private Main plugin;

	public Back(Main pl) {
		plugin = pl;
	}

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!(sender instanceof Player)) {
			Logger logger = Bukkit.getLogger();
			if (args.length == 0) {
				api.incorrectSyntaxConsole("/back <player>");
				return true;
			} else if (args.length > 0) {
				Player target = Bukkit.getPlayerExact(args[0]);
				if (target == null) {
					api.pNotFoundConsole(args[0]);
					return true;
				} else {
					if (playerDeath.deathInfo.containsKey(target.getName())) {
						Location loc = playerDeath.deathInfo.get(target.getName());
						api.tpDelayLoc(loc, target, plugin);
						logger.info("Player " + target.getName() + " sent to their last death location.");
						return true;
					} else {
						logger.info("That player hasn't died recently!");
						return true;
					}
				}

			} else {
				api.incorrectSyntaxConsole("/back <player>");
				return true;
			}
		} else {
			Player p = (Player) sender;
			if (args.length == 0) {
				if (p.hasPermission("jessentials.back")) {
					if (playerDeath.deathInfo.containsKey(p.getName())) {
						Location loc = playerDeath.deathInfo.get(p.getName());
						api.tpDelayLoc(loc, p, plugin);
						return true;
					} else {
						p.sendMessage(ChatColor.DARK_RED + "You have not died recently!");
						return true;
					}
					
				} else {
					api.noPermission(p);
					return true;
				}
			} else if (args.length == 1) {
				if (p.hasPermission("jessentials.back.others")) {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						api.pNotFound(p, args[0]);
						return true;
					} else {
						if (playerDeath.deathInfo.containsKey(target.getName())) {
							Location loc = playerDeath.deathInfo.get(target.getName());
							api.tpDelayLoc(loc, target, plugin);
							p.sendMessage(ChatColor.GOLD + "Player " + target.getName() + " sent to their last death location.");
							return true;
						} else {
							p.sendMessage(ChatColor.DARK_RED + "That player has not died recently!");
							return true;
						}
					}
				} else {
					api.noPermission(p);
					return true;
				}
			} else {
				api.incorrectSyntax(p, "/back ; /back <player>");
				return true;
			}
		}
	}

}
