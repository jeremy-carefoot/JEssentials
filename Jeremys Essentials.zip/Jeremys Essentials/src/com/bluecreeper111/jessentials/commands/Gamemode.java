package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.bluecreeper111.jessentials.Main;

public class Gamemode implements CommandExecutor {

	private Main plugin;

	public Gamemode(Main pl) {
		plugin = pl;
	}

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Logger logger = Bukkit.getLogger();
		String notPlayer = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPlayerMessage"));
		String noPermission = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPermissionMessage"));
		String gmcMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("gmcMessage"));
		String gmsMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("gmsMessage"));
		String gmaMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("gmaMessage"));
		String gmspMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("gmspMessage"));
		String pNotFound = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("pNotFoundMessage"));

		if (cmd.getName().equalsIgnoreCase("gmc")) {
			if (args.length < 1) {
				if (!(sender instanceof Player)) {
					logger.info(notPlayer);
					return true;
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gmc")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						player.setGameMode(GameMode.CREATIVE);
						player.sendMessage(gmcMessage.replaceAll("%player%", player.getName().toString()));
						return true;

					}
				}
			} else {
				if (!(sender instanceof Player)) {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						logger.info(pNotFound.replaceAll("%target%", args[0].toString()));
						return true;
					} else {
						target.setGameMode(GameMode.CREATIVE);
						target.sendMessage(gmcMessage.replaceAll("%player%", target.getName().toString()));
						logger.info("Gamemode for player " + target.getName() + " switched to creative.");
						return true;
					}
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gmc.others")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						Player target = Bukkit.getPlayerExact(args[0]);
						if (target == null) {
							player.sendMessage(pNotFound.replaceAll("%target%", args[0].toString()));
							return true;
						} else {
							target.setGameMode(GameMode.CREATIVE);
							target.sendMessage(gmcMessage.replaceAll("%player%", target.getName().toString()));
							player.sendMessage(ChatColor.GOLD + "Player " + target.getName()
									+ "'s  gamemode switched to creative.");
							return true;
						}
					}
				}
			}
		}
		
		if (cmd.getName().equalsIgnoreCase("gms")) {
			if (args.length < 1) {
				if (!(sender instanceof Player)) {
					logger.info(notPlayer);
					return true;
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gms")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						player.setGameMode(GameMode.SURVIVAL);
						player.sendMessage(gmsMessage.replaceAll("%player%", player.getName().toString()));
						return true;

					}
				}
			} else {
				if (!(sender instanceof Player)) {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						logger.info(pNotFound.replaceAll("%target%", args[0].toString()));
						return true;
					} else {
						target.setGameMode(GameMode.SURVIVAL);
						target.sendMessage(gmsMessage.replaceAll("%player%", target.getName().toString()));
						logger.info("Gamemode for player " + target.getName() + " switched to survival.");
						return true;
					}
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gms.others")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						Player target = Bukkit.getPlayerExact(args[0]);
						if (target == null) {
							player.sendMessage(pNotFound.replaceAll("%target%", args[0].toString()));
							return true;
						} else {
							target.setGameMode(GameMode.SURVIVAL);
							target.sendMessage(gmsMessage.replaceAll("%player%", target.getName().toString()));
							player.sendMessage(ChatColor.GOLD + "Player " + target.getName()
									+ "'s  gamemode switched to Survival.");
							return true;
						}
					}
				}
			}
		}
		
		if (cmd.getName().equalsIgnoreCase("gma")) {
			if (args.length < 1) {
				if (!(sender instanceof Player)) {
					logger.info(notPlayer);
					return true;
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gma")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						player.setGameMode(GameMode.ADVENTURE);
						player.sendMessage(gmaMessage.replaceAll("%player%", player.getName().toString()));
						return true;

					}
				}
			} else {
				if (!(sender instanceof Player)) {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						logger.info(pNotFound.replaceAll("%target%", args[0].toString()));
						return true;
					} else {
						target.setGameMode(GameMode.ADVENTURE);
						target.sendMessage(gmaMessage.replaceAll("%player%", target.getName().toString()));
						logger.info("Gamemode for player " + target.getName() + " switched to adventure.");
						return true;
					}
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gma.others")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						Player target = Bukkit.getPlayerExact(args[0]);
						if (target == null) {
							player.sendMessage(pNotFound.replaceAll("%target%", args[0].toString()));
							return true;
						} else {
							target.setGameMode(GameMode.ADVENTURE);
							target.sendMessage(gmaMessage.replaceAll("%player%", target.getName().toString()));
							player.sendMessage(ChatColor.GOLD + "Player " + target.getName()
									+ "'s  gamemode switched to adventure.");
							return true;
						}
					}
				}
			}
		}
		
		if (cmd.getName().equalsIgnoreCase("gmsp")) {
			if (args.length < 1) {
				if (!(sender instanceof Player)) {
					logger.info(notPlayer);
					return true;
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gmsp")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						player.setGameMode(GameMode.SPECTATOR);
						player.sendMessage(gmspMessage.replaceAll("%player%", player.getName().toString()));
						return true;

					}
				}
			} else {
				if (!(sender instanceof Player)) {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						logger.info(pNotFound.replaceAll("%target%", args[0].toString()));
						return true;
					} else {
						target.setGameMode(GameMode.SPECTATOR);
						target.sendMessage(gmspMessage.replaceAll("%player%", target.getName().toString()));
						logger.info("Gamemode for player " + target.getName() + " switched to spectator.");
						return true;
					}
				} else {
					Player player = (Player) sender;
					if (!player.hasPermission("jessentials.gmsp.others")) {
						player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						Player target = Bukkit.getPlayerExact(args[0]);
						if (target == null) {
							player.sendMessage(pNotFound.replaceAll("%target%", args[0].toString()));
							return true;
						} else {
							target.setGameMode(GameMode.SPECTATOR);
							target.sendMessage(gmspMessage.replaceAll("%player%", target.getName().toString()));
							player.sendMessage(ChatColor.GOLD + "Player " + target.getName()
									+ "'s  gamemode switched to spectator.");
							return true;
						}
					}
				}
			}
		}
	
		return true;
	}

}
