package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginDescriptionFile;

import com.bluecreeper111.jessentials.Main;
import com.bluecreeper111.jessentials.api.api;

public class JEssentials implements CommandExecutor {

	private Main plugin;

	public JEssentials(Main pl) {
		plugin = pl;
	}

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Logger logger = Bukkit.getLogger();
		PluginDescriptionFile pdf = plugin.getDescription();
		String noPermission = ChatColor.translateAlternateColorCodes('&',
				plugin.getConfig().getString("noPermissionMessage"));
		String configReload = ChatColor.translateAlternateColorCodes('&',
				plugin.getConfig().getString("configReloadMessage"));

		if (!(sender instanceof Player)) {
			if (args.length == 0) {
				logger.info(ChatColor.GOLD + "Jeremy's Essentials version V." + pdf.getVersion()
						+ " developed by bluecreeper111");
				return true;
			} else if (args[0].equalsIgnoreCase("reload")) {
				plugin.reloadConfig();
				logger.info(configReload);
				return true;
			} else {
				api.incorrectSyntaxConsole("/jessentials [reload]");
				return true;
			}
		} else {
			Player p = (Player) sender;
			if (args.length == 0) {
				if (sender instanceof Player && p.hasPermission("jessentials.info")) {
					p.sendMessage(ChatColor.GOLD + "Jeremy's Essentials version V." + pdf.getVersion()
							+ " developed by bluecreeper111");
					return true;
				} else {
					p.sendMessage(noPermission.replaceAll("%player%", p.getName().toString()));
					return true;
				}
			} else if (args[0].equalsIgnoreCase("reload")) {
				if (p.hasPermission("jessentials.reload")) {
					plugin.reloadConfig();
					p.sendMessage(configReload);
					return true;
				} else {
					api.noPermission(p);
					return true;
				}
			} else {
				api.incorrectSyntax(p, "/jessentials [reload]");
			}
		}
		return true;
	}

}
