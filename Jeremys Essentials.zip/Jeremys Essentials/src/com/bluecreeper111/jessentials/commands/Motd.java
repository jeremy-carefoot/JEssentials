package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.bluecreeper111.jessentials.Main;
import com.bluecreeper111.jessentials.api.api;

public class Motd implements CommandExecutor {

	private Main plugin;

	public Motd(Main pl) {
		plugin = pl;
	}

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		String motd = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("motd"));
		if (args.length == 0) {
			if (!(sender instanceof Player)) {
				Logger logger = Bukkit.getLogger();
				logger.info(motd.replaceAll("%player%", "console"));
				return true;
			} else {
				Player p = (Player) sender;
				if (!p.hasPermission("jessentials.motd")) {
					api.noPermission(p);
					return true;
				} else {
					p.sendMessage(motd.replaceAll("%player%", p.getName().toString()));
					return true;
				}
			}

		} else if (args.length > 0 && args[0].equalsIgnoreCase("set")) {
			if (!(sender instanceof Player)) {
				Logger logger = Bukkit.getLogger();
				if (!(args.length > 1)) {
					api.incorrectSyntaxConsole("/motd set <message>");
					return true;
				} else {
					String text = "";
					for (int i = 1; i < args.length; i++) {
						text = text + ChatColor.translateAlternateColorCodes('&', args[i]) + " ";
					}
					plugin.getConfig().set("motd", text);
					plugin.saveConfig();
					logger.info("MOTD has been set to: " + text);
					return true;
				}
			} else {
				Player p = (Player) sender;
				if (!p.hasPermission("jessentials.motd.set")) {
					api.noPermission(p);
					return true;
				} else {
					if (!(args.length > 1)) {
						api.incorrectSyntax(p, "/motd set <message>");
						return true;
					} else {
						String text = "";
						for (int i = 1; i < args.length; i++) {
							text = text + ChatColor.translateAlternateColorCodes('&', args[i]) + " ";
						}
						plugin.getConfig().set("motd", text);
						plugin.saveConfig();
						p.sendMessage(ChatColor.GREEN + "MOTD has been set to: " + text);
						return true;
					}
				}
			}
		} else if (args.length > 0 && args[0].equalsIgnoreCase("enable")) {
			if (!(sender instanceof Player)) {
				Logger logger = Bukkit.getLogger();
				if (!(args.length == 2)) {
					api.incorrectSyntaxConsole("/motd enable [true:false]");
					return true;
				} else {
					if (args[1].equalsIgnoreCase("true") || args[1].equalsIgnoreCase("false")) {
						boolean value = Boolean.parseBoolean(args[1]);
						plugin.getConfig().set("enable-motd", value);
						plugin.saveConfig();
						logger.info("MOTD-enabled has been set to " + args[1]);
						return true;
					} else {
						api.incorrectSyntaxConsole("/motd enable [true:false]");
						return true;
					}
				}
			} else {
				Player p = (Player) sender;
				if (!p.hasPermission("jessentials.motd.enable")) {
					api.noPermission(p);
					return true;
				} else {
					if (args.length != 2) {
						api.incorrectSyntax(p, "/motd enable [true:false]");
						return true;
					} else {
						if (args[1].equalsIgnoreCase("true") || args[1].equalsIgnoreCase("false")) {
							boolean value = Boolean.parseBoolean(args[1]);
							plugin.getConfig().set("enable-motd", value);
							plugin.saveConfig();
							p.sendMessage(ChatColor.DARK_GREEN + "MOTD-enabled has been set to " + ChatColor.GOLD + args[1]);
							return true;
							
						} else {
							api.incorrectSyntax(p, "/motd enable [true:false]");
							return true;
						}
					}
				}
			}
		}
		return true;
	}

}
