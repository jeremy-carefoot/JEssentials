package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.bluecreeper111.jessentials.Main;

public class Clear implements CommandExecutor {
	
	private Main plugin;
	
	public Clear(Main pl) {
		plugin = pl;
	}

	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		String notPlayer = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPlayerMessage"));
		String nPermission = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPermissionMessage"));
		String pNotFound = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("pNotFoundMessage"));
		String clearMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("clearMessage"));
		Logger logger = Bukkit.getLogger();
		
		if (args.length < 1) {
			if (!(sender instanceof Player)) {
				logger.info(notPlayer);
				return true;
			} else {
				Player player = (Player) sender;
				if(!player.hasPermission("jessentials.clear")) {
					player.sendMessage(nPermission.replaceAll("%player%", player.getName().toString()));
					return true;
				} else {
					player.getInventory().clear();
					player.sendMessage(clearMessage.replaceAll("%player%", player.getName().toString()));
					return true;
				}
			}
			
		} else {
			if (!(sender instanceof Player)) {
				Player target = Bukkit.getPlayerExact(args[0]);
				if (target == null) {
					logger.info(pNotFound.replaceAll("%target%", args[0].toString()));
					return true;
				}
				target.getInventory().clear();
				target.sendMessage(clearMessage.replaceAll("%target%", target.getName().toString()));
				logger.info(target.getName() + "'s inventory has been cleared.");
				return true;
			} else {
				Player player = (Player) sender;
				if (!player.hasPermission("jessentials.clear.others")) {
					player.sendMessage(nPermission.replaceAll("%player%", player.getName().toString()));
					return true;
				} else {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						player.sendMessage(pNotFound.replaceAll("%target%", args[0].toString()));
						return true;
					}
					target.getInventory().clear();
					target.sendMessage(clearMessage.replaceAll("%target%", target.getName().toString()));
					player.sendMessage(ChatColor.GOLD + target.getName() + "'s inventory has been cleared.");
					return true;
				}
				
			}
		}
	}

}
