package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;

import com.bluecreeper111.jessentials.Main;

public class Workbench implements CommandExecutor {
	
	private Main plugin;
	
	public Workbench(Main pl) {
		plugin = pl;
	}

	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		Logger logger = Bukkit.getLogger();
		String noPlayer = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPlayerMessage"));
		String wbMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("wbMessage"));
		String noPermission = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPermissionMessage"));
		
		if (!(sender instanceof Player)) {
			logger.info(noPlayer);
			return true;
		} else {
			Player player = (Player) sender;
			if (!player.hasPermission("jessentials.workbench")) {
				player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
				return true;
			} else {
				Inventory craft = Bukkit.createInventory(player, InventoryType.WORKBENCH);
				player.openInventory(craft);
				player.openWorkbench(null, true);
				player.sendMessage(wbMessage.replaceAll("%player%", player.getName().toString()));
				return true;
			}
			
		}
		
	}

}
