package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.bluecreeper111.jessentials.Main;

public class Fly implements CommandExecutor {

	private Main plugin;

	public Fly(Main pl) {
		plugin = pl;
	}

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		String notPlayer = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPlayerMessage"));
		String noPermission = ChatColor.translateAlternateColorCodes('&', plugin.getConfig()
				.getString("noPermissionMessage"));
		String enableFly = ChatColor.translateAlternateColorCodes('&',
				plugin.getConfig().getString("flyEnableMessage"));
		String disableFly = ChatColor.translateAlternateColorCodes('&',
				plugin.getConfig().getString("flyDisableMessage"));
		String pNotFound = ChatColor.translateAlternateColorCodes('&',
				plugin.getConfig().getString("pNotFoundMessage"));
		Logger logger = Bukkit.getLogger();

		if (args.length < 1) {
			if (!(sender instanceof Player)) {
				logger.info(notPlayer);
				return true;
			} else {
				Player player = (Player) sender;
				if (!player.hasPermission("jessentials.fly")) {
					player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
					return true;
				} else {
					if (player.getAllowFlight() == true) {
						player.setAllowFlight(false);
						player.sendMessage(disableFly.replaceAll("%player%", player.getName().toString()));
						return true;
					} else {
						player.setAllowFlight(true);
						player.sendMessage(enableFly.replaceAll("%player%", player.getName().toString()));
						return true;
					}
				}
			}
		} else {
			if (!(sender instanceof Player)) {
				Player target = Bukkit.getPlayerExact(args[0]);
				if (target == null) {
					logger.info(pNotFound.replaceAll("%target%", args[0].toString()));
					return true;
				} else {
					if (target.getAllowFlight() == true) {
						target.setAllowFlight(false);
						target.sendMessage(disableFly.replaceAll("%player%", target.getName().toString()));
						logger.info("Flight disabled for " + target.getName());
						return true;
					} else {
						target.setAllowFlight(true);
						target.sendMessage(enableFly.replaceAll("%player%", target.getName().toString()));
						logger.info("Flight enabled for " + target.getName());
						return true;
					}
				}
			} else {
				Player player = (Player) sender;
				if (!(player.hasPermission("jessentials.fly.others"))) {
					player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
					return true;
				} else {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						player.sendMessage(pNotFound.replaceAll("%target%", args[0].toString()));
						return true;
					} else {
						if (target.getAllowFlight() == false) {
							target.setAllowFlight(true);
							target.sendMessage(enableFly.replaceAll("%player%", target.getName().toString()));
							player.sendMessage(ChatColor.GOLD + "Flight enabled for " + target.getName());
							return true;
						} else {
							target.setAllowFlight(false);
							target.sendMessage(disableFly.replaceAll("%player%", target.getName().toString()));
							player.sendMessage(ChatColor.GOLD + "Flight disabled for " + target.getName());
							return true;
						}
					}
				}
			}
		}
	}

}
