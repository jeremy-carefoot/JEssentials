package com.bluecreeper111.jessentials.commands;

import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.bluecreeper111.jessentials.Main;

import net.md_5.bungee.api.ChatColor;

public class Heal implements CommandExecutor {

	private Main plugin;

	public Heal(Main pl) {
		plugin = pl;
	}

	public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
		
		Logger logger = Bukkit.getLogger();

		if (args.length < 1) {
			if (!(sender instanceof Player)) {
				String notPlayerM = plugin.getConfig().getString("noPlayerMessage");
				logger.info(ChatColor.translateAlternateColorCodes('&',notPlayerM));
				return true;
			} else {
				Player player = (Player) sender;
				if (!player.hasPermission("jessentials.heal")) {
					String nPermission = plugin.getConfig().getString("noPermissionMessage").replaceAll("%player%", player.getName().toString());
					player.sendMessage(ChatColor.translateAlternateColorCodes('&', nPermission));
					return true;
				} else if (player.hasPermission("jessentials.heal")) {
					String healMessage = plugin.getConfig().getString("healMessage").replaceAll("%player%", player.getName().toString());
					player.setHealth(20);
					player.sendMessage(ChatColor.translateAlternateColorCodes('&', healMessage));
					return true;
				}
			}
		} else {
			if (!(sender instanceof Player)) {
				Player target = Bukkit.getPlayerExact(args[0]);
				if (target == null) {
					String playerNull = plugin.getConfig().getString("pNotFoundMessage").replaceAll("%target%", args[0].toString());
					logger.info(ChatColor.translateAlternateColorCodes('&', playerNull));
					return true;
				} else {
					String healMessage = plugin.getConfig().getString("healMessage").replace("%player%", target.getName().toString());
					target.setHealth(20);
					target.sendMessage(ChatColor.translateAlternateColorCodes('&', healMessage));
					logger.info("Player " + target.getName() + " was healed.");
					return true;
				}
			} else {
				Player player = (Player) sender;
				if (!player.hasPermission("jessentials.heal.others")) {
					String nPermission = plugin.getConfig().getString("noPermissionMessage").replaceAll("%player%", player.getName().toString());
					player.sendMessage(ChatColor.translateAlternateColorCodes('&', nPermission));
					return true;
				} else if (player.hasPermission("jessentials.heal.others")) {
					Player target = Bukkit.getPlayerExact(args[0]);
					if (target == null) {
						String playerNull = plugin.getConfig().getString("pNotFoundMessage");
						player.sendMessage(ChatColor.translateAlternateColorCodes('&', playerNull));
						return true;
					} else {
						String healMessage = plugin.getConfig().getString("healMessage").replace("%player%", target.getName().toString());
						target.setHealth(20);
						target.sendMessage(ChatColor.translateAlternateColorCodes('&', healMessage));
						sender.sendMessage(ChatColor.GOLD + "Player " + target.getName() + " was healed.");
						return true;
					}
				}

			}

			return true;
		}
		return true;
	}
}
