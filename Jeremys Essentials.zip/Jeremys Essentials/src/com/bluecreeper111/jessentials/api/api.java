package com.bluecreeper111.jessentials.api;

import java.util.HashMap;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import com.bluecreeper111.jessentials.Main;

public class api extends Main {

	public static HashMap<String, Boolean> tpDelayCancelled = new HashMap<String, Boolean>();

	public static void noPermission(Player player) {
		player.sendMessage(ChatColor.translateAlternateColorCodes('&',
				noPermissionMessage.replaceAll("%player%", player.getName().toString())));
	}

	public static void pNotFound(Player player, String args) {
		player.sendMessage(ChatColor.translateAlternateColorCodes('&', playerNotFound.replaceAll("%target%", args)));
	}

	public static void pNotFoundConsole(String args) {
		Logger logger = Bukkit.getLogger();
		logger.info(ChatColor.translateAlternateColorCodes('&', playerNotFound.replaceAll("%target%", args)));
	}

	public static void notPlayer() {
		Logger logger = Bukkit.getLogger();
		logger.info(ChatColor.translateAlternateColorCodes('&', notPlayerMessage));
	}

	public static void incorrectSyntax(Player player, String syntax) {
		player.sendMessage(
				ChatColor.translateAlternateColorCodes('&', incorrectSyntaxMessage.replaceAll("%syntax%", syntax)));
	}

	public static void incorrectSyntaxConsole(String syntax) {
		Logger logger = Bukkit.getLogger();
		logger.info(ChatColor.translateAlternateColorCodes('&', incorrectSyntaxMessage.replaceAll("%syntax%", syntax)));
	}

	public static void tpDelayLoc(Location loc, Player p, Main plugin) {
		if (tpDelayEnable == true) {
			if (p.hasPermission("jessentials.tpdelay.bypass")) {
				p.teleport(loc);
				tpSafetyLoc(p, plugin);
				p.sendMessage(ChatColor.GOLD + "Teleported!");
			}
			tpDelayCancelled.put(p.getName(), false);
			teleportDelay.tpDelayPlayers.add(p.getName());
			p.sendMessage(teleportMessage.replaceAll("%player%", p.getName().toString()).replaceAll("%delay%", Long.toString(tpDelay / 20)));
			scheduler.scheduleSyncDelayedTask(plugin, new Runnable() {
				public void run() {
					teleportDelay.tpDelayPlayers.remove(p.getName());
					if (tpDelayCancelled.get(p.getName()) == false) {
						p.teleport(loc);
						tpSafetyLoc(p, plugin);
						p.sendMessage(ChatColor.GOLD + "Teleported!");
						return;
					} else {
						p.sendMessage(ChatColor.RED + "Teleport cancelled because you moved!");
						return;
					}
				}
			}, tpDelay);

		} else {
			p.teleport(loc);
			tpSafetyLoc(p, plugin);
			p.sendMessage(ChatColor.GOLD + "Teleported!");
		}
	}

	public static void tpSafetyLoc(Player p, Main plugin) {
		teleportSafety.tpSafety.add(p.getName());
		scheduler.scheduleSyncDelayedTask(plugin, new Runnable() {
			public void run() {
				teleportSafety.tpSafety.remove(p.getName());
			}
		}, tpSafetyLength);
	}
	
	public static String replacePlayer(String message, Player p) {
		return message.replaceAll("%player%", p.getName().toString());
	}

}
