package com.bluecreeper111.jessentials.event;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import com.bluecreeper111.jessentials.Main;

public class playerJoinLeave implements Listener {
	
	private Main plugin;
	
	public playerJoinLeave(Main pl) {
		plugin = pl;
	}
	
	@EventHandler
	public void playerJoin(PlayerJoinEvent e) {
		String joinMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("joinMessage"));
		String motd = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("motd"));
		e.setJoinMessage(joinMessage.replaceAll("%player%", e.getPlayer().getName().toString()));
		if (plugin.getConfig().getBoolean("enable-motd") == true) {
			e.getPlayer().sendMessage(motd.replaceAll("%player%", e.getPlayer().getName()));
		}
	}
	
	@EventHandler
	public void playerLeave(PlayerQuitEvent e) {
		String leaveMessage = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("leaveMessage"));
		e.setQuitMessage(leaveMessage.replaceAll("%player%", e.getPlayer().getName().toString()));
	}

}
