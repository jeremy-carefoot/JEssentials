package com.bluecreeper111.jessentials.event;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import com.bluecreeper111.jessentials.Main;

public class playerGive implements Listener {
	
	private Main plugin;
	public playerGive(Main pl) {
		plugin = pl;
	}
	
	@EventHandler
	public void onPlayerGive(PlayerCommandPreprocessEvent event) {
		String noPermission = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPermissionMessage"));
		if (event.getMessage().toLowerCase().startsWith("/give")) {
			Player player = event.getPlayer();
			if (!player.hasPermission("jessentials.give")) {
				event.setCancelled(true);
				player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
			} else {
				event.setCancelled(false);
			}
		}
	}

}
