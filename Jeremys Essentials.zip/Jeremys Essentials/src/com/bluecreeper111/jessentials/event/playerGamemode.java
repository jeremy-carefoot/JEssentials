package com.bluecreeper111.jessentials.event;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import com.bluecreeper111.jessentials.Main;

public class playerGamemode implements Listener {
	
	private Main plugin;
	
	public playerGamemode(Main pl) {
		plugin = pl;
	}
	
	@EventHandler(priority = EventPriority.LOWEST)
	public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
		String noPermission = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("noPermissionMessage"));
		if (event.getMessage().toLowerCase().startsWith("/gamemode")) {
			Player player = event.getPlayer();
			if (!player.hasPermission("jessentials.gamemode")) {
				player.sendMessage(noPermission.replaceAll("%player%", player.getName().toString()));
				event.setCancelled(true);
			} else {
				event.setCancelled(false);
			}
		}
	}

}
